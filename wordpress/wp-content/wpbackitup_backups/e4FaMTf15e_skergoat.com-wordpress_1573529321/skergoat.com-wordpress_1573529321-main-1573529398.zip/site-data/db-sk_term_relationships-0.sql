-- ------------------------------------------------------
-- ------------------------------------------------------
--
-- WPBackItUp Database Export 
--
-- Created: 2019/11/12 on 02:29
--
-- Database : skergoat_wordpress
--
-- Backup   Table  : sk_term_relationships
-- Snapshot Table  : 1573529321_term_relationships
--
-- SQL    : SELECT * FROM sk_term_relationships LIMIT 0,10000
-- Offset : 0
-- Rows   : 34
-- ------------------------------------------------------
-- ------------------------------------------------------
SET AUTOCOMMIT = 0 ;
SET FOREIGN_KEY_CHECKS=0 ;

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40101 SET SESSION sql_mode = '' */;

--
-- Table structure for table `1573529321_term_relationships`
--
DROP TABLE  IF EXISTS `1573529321_term_relationships`;
CREATE TABLE `1573529321_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `term_order` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



--
-- Data for table `sk_term_relationships`
-- Number of rows: 34
--
INSERT INTO `1573529321_term_relationships` VALUES 
(20,2,0),
 (22,2,0),
 (23,2,0),
 (24,2,0),
 (217,9,0),
 (217,11,0),
 (219,9,0),
 (219,11,0),
 (221,9,0),
 (221,13,0),
 (223,9,0),
 (223,12,0),
 (225,8,0),
 (225,15,0),
 (227,8,0),
 (227,14,0),
 (229,8,0),
 (229,14,0),
 (231,8,0),
 (231,15,0),
 (233,8,0),
 (233,14,0),
 (235,8,0),
 (235,15,0),
 (237,9,0),
 (237,12,0),
 (240,9,0),
 (240,13,0),
 (253,16,0),
 (255,16,0),
 (256,16,0),
 (257,16,0),
 (1038,2,0),
 (1040,16,0);

SET FOREIGN_KEY_CHECKS = 1 ; 
COMMIT ; 
SET AUTOCOMMIT = 1 ; 
