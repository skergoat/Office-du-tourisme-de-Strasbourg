-- ------------------------------------------------------
-- ------------------------------------------------------
--
-- WPBackItUp Database Export 
--
-- Created: 2019/11/12 on 02:29
--
-- Database : skergoat_wordpress
--
-- Backup   Table  : sk_term_taxonomy
-- Snapshot Table  : 1573529321_term_taxonomy
--
-- SQL    : SELECT * FROM sk_term_taxonomy LIMIT 0,10000
-- Offset : 0
-- Rows   : 11
-- ------------------------------------------------------
-- ------------------------------------------------------
SET AUTOCOMMIT = 0 ;
SET FOREIGN_KEY_CHECKS=0 ;

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40101 SET SESSION sql_mode = '' */;

--
-- Table structure for table `1573529321_term_taxonomy`
--
DROP TABLE  IF EXISTS `1573529321_term_taxonomy`;
CREATE TABLE `1573529321_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `taxonomy` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `description` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT 0,
  `count` bigint(20) NOT NULL DEFAULT 0,
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



--
-- Data for table `sk_term_taxonomy`
-- Number of rows: 11
--
INSERT INTO `1573529321_term_taxonomy` VALUES 
(1,1,'category','',0,0),
 (2,2,'nav_menu','',0,5),
 (8,8,'category','',0,6),
 (9,9,'category','',0,6),
 (11,11,'category','',9,2),
 (12,12,'category','',9,2),
 (13,13,'category','',9,2),
 (14,14,'category','',8,3),
 (15,15,'category','',8,3),
 (16,16,'nav_menu','',0,5),
 (17,17,'category','',0,0);

SET FOREIGN_KEY_CHECKS = 1 ; 
COMMIT ; 
SET AUTOCOMMIT = 1 ; 
