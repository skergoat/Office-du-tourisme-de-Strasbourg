-- ------------------------------------------------------
-- ------------------------------------------------------
--
-- WPBackItUp Database Export 
--
-- Created: 2019/11/12 on 02:29
--
-- Database : skergoat_wordpress
--
-- Backup   Table  : sk_usermeta
-- Snapshot Table  : 1573529321_usermeta
--
-- SQL    : SELECT * FROM sk_usermeta LIMIT 0,10000
-- Offset : 0
-- Rows   : 50
-- ------------------------------------------------------
-- ------------------------------------------------------
SET AUTOCOMMIT = 0 ;
SET FOREIGN_KEY_CHECKS=0 ;

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40101 SET SESSION sql_mode = '' */;

--
-- Table structure for table `1573529321_usermeta`
--
DROP TABLE  IF EXISTS `1573529321_usermeta`;
CREATE TABLE `1573529321_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=82 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



--
-- Data for table `sk_usermeta`
-- Number of rows: 50
--
INSERT INTO `1573529321_usermeta` VALUES 
(1,1,'nickname','skergoat'),
 (2,1,'first_name',''),
 (3,1,'last_name',''),
 (4,1,'description',''),
 (5,1,'rich_editing','true'),
 (6,1,'syntax_highlighting','true'),
 (7,1,'comment_shortcuts','false'),
 (8,1,'admin_color','midnight'),
 (9,1,'use_ssl','0'),
 (10,1,'show_admin_bar_front','true'),
 (11,1,'locale',''),
 (12,1,'sk_capabilities','a:1:{s:13:\"administrator\";b:1;}'),
 (13,1,'sk_user_level','10'),
 (14,1,'dismissed_wp_pointers','wp496_privacy'),
 (15,1,'show_welcome_panel','0'),
 (17,1,'sk_dashboard_quick_press_last_post_id','897'),
 (18,1,'community-events-location','a:1:{s:2:\"ip\";s:12:\"103.61.124.0\";}'),
 (19,1,'managenav-menuscolumnshidden','a:5:{i:0;s:11:\"link-target\";i:1;s:11:\"css-classes\";i:2;s:3:\"xfn\";i:3;s:11:\"description\";i:4;s:15:\"title-attribute\";}'),
 (20,1,'metaboxhidden_nav-menus','a:1:{i:0;s:12:\"add-post_tag\";}'),
 (21,1,'sk_user-settings','libraryContent=browse&editor=tinymce&imgsize=full&editor_plain_text_paste_warning=2&advImgDetails=hide'),
 (22,1,'sk_user-settings-time','1569309749'),
 (23,1,'supsystic-tables-tutorial_was_showed','1'),
 (24,1,'closedpostboxes_foogallery','a:0:{}'),
 (25,1,'metaboxhidden_foogallery','a:1:{i:0;s:7:\"slugdiv\";}'),
 (26,1,'yotuwp_scgen_ignore_notice',''),
 (28,1,'_pum_reviews_dismissed_triggers','a:2:{s:14:\"time_installed\";s:2:\"20\";s:10:\"open_count\";s:2:\"10\";}'),
 (29,1,'_pum_reviews_last_dismissed','2018-11-12 09:45:11'),
 (33,1,'_yoast_wpseo_profile_updated','1569317914'),
 (34,1,'show_try_gutenberg_panel','0'),
 (36,1,'yotuwp_rating_ignore_notice','1'),
 (40,1,'wpseo_title',''),
 (41,1,'wpseo_metadesc',''),
 (42,1,'wpseo_noindex_author',''),
 (43,1,'wpseo_content_analysis_disable',''),
 (44,1,'wpseo_keyword_analysis_disable',''),
 (64,1,'default_password_nag',''),
 (65,1,'session_tokens','a:4:{s:64:\"09cd1243325df922be844a90cf5ba6a2c2042b2126426a6d45d5b3637e880b89\";a:4:{s:10:\"expiration\";i:1573619116;s:2:\"ip\";s:14:\"103.61.124.234\";s:2:\"ua\";s:120:\"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.87 Safari/537.36\";s:5:\"login\";i:1573446316;}s:64:\"a8c5bf69dcf37e17721d1fa816b1aa3ec1f8486f807ae21699b5b17bff7e6335\";a:4:{s:10:\"expiration\";i:1573626555;s:2:\"ip\";s:14:\"103.61.124.234\";s:2:\"ua\";s:140:\"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.99 Safari/537.36 Vivaldi/2.9.1705.41\";s:5:\"login\";i:1573453755;}s:64:\"c092d7ce3f2c9c8697f7dbdd1563ce53a15b47f5ba1f1135220048b48e59cb27\";a:4:{s:10:\"expiration\";i:1573643020;s:2:\"ip\";s:14:\"103.61.124.234\";s:2:\"ua\";s:120:\"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.86 Safari/537.36\";s:5:\"login\";i:1573470220;}s:64:\"0f76a9efd05b3bc3f04adc27b3aa987fc95339c0a12e28f67ea4e925811928e7\";a:4:{s:10:\"expiration\";i:1573652618;s:2:\"ip\";s:14:\"103.61.124.234\";s:2:\"ua\";s:140:\"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.99 Safari/537.36 Vivaldi/2.9.1705.41\";s:5:\"login\";i:1573479818;}}'),
 (66,1,'_pum_dismissed_alerts','a:0:{}'),
 (70,1,'facebook',''),
 (71,1,'instagram',''),
 (72,1,'linkedin',''),
 (73,1,'myspace',''),
 (74,1,'pinterest',''),
 (75,1,'soundcloud',''),
 (76,1,'tumblr',''),
 (77,1,'twitter',''),
 (78,1,'youtube',''),
 (79,1,'wikipedia',''),
 (80,1,'sk_yoast_notifications','a:2:{i:0;a:2:{s:7:\"message\";s:374:\"L’assistant de configuration vous aide à configurer facilement votre site pour avoir des réglages SEO optimaux.<br/>Nous avons détecté que vous n’avez pas suivi jusqu’au bout l’assistant. Nous vous recommandons donc de <a href=\"https://skergoat.com/wordpress/wp-admin/?page=wpseo_configurator\">lancer l’assistant de configuration pour configurer Yoast SEO</a>.\";s:7:\"options\";a:9:{s:4:\"type\";s:7:\"warning\";s:2:\"id\";s:31:\"wpseo-dismiss-onboarding-notice\";s:5:\"nonce\";N;s:8:\"priority\";d:0.8000000000000000444089209850062616169452667236328125;s:9:\"data_json\";a:0:{}s:13:\"dismissal_key\";N;s:12:\"capabilities\";s:20:\"wpseo_manage_options\";s:16:\"capability_check\";s:3:\"all\";s:14:\"yoast_branding\";b:0;}}i:1;a:2:{s:7:\"message\";s:304:\"<strong>Important problème SEO : Vous bloquez actuellement l’accès aux robots des moteurs de recherche.</strong> Vous devez vous <a href=\"https://skergoat.com/wordpress/wp-admin/options-reading.php\">rendre dans vos Réglages de Lecture</a> et décocher la case Visibilité  des moteurs de recherche.\";s:7:\"options\";a:9:{s:4:\"type\";s:5:\"error\";s:2:\"id\";s:32:\"wpseo-dismiss-blog-public-notice\";s:5:\"nonce\";N;s:8:\"priority\";i:1;s:9:\"data_json\";a:0:{}s:13:\"dismissal_key\";N;s:12:\"capabilities\";s:20:\"wpseo_manage_options\";s:16:\"capability_check\";s:3:\"all\";s:14:\"yoast_branding\";b:0;}}}'),
 (81,1,'nav_menu_recently_edited','2');

SET FOREIGN_KEY_CHECKS = 1 ; 
COMMIT ; 
SET AUTOCOMMIT = 1 ; 
