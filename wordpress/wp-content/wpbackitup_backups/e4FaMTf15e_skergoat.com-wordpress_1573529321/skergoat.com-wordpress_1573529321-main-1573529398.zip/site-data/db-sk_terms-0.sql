-- ------------------------------------------------------
-- ------------------------------------------------------
--
-- WPBackItUp Database Export 
--
-- Created: 2019/11/12 on 02:29
--
-- Database : skergoat_wordpress
--
-- Backup   Table  : sk_terms
-- Snapshot Table  : 1573529321_terms
--
-- SQL    : SELECT * FROM sk_terms LIMIT 0,10000
-- Offset : 0
-- Rows   : 11
-- ------------------------------------------------------
-- ------------------------------------------------------
SET AUTOCOMMIT = 0 ;
SET FOREIGN_KEY_CHECKS=0 ;

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40101 SET SESSION sql_mode = '' */;

--
-- Table structure for table `1573529321_terms`
--
DROP TABLE  IF EXISTS `1573529321_terms`;
CREATE TABLE `1573529321_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `slug` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT 0,
  PRIMARY KEY (`term_id`),
  KEY `slug` (`slug`(191)),
  KEY `name` (`name`(191))
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



--
-- Data for table `sk_terms`
-- Number of rows: 11
--
INSERT INTO `1573529321_terms` VALUES 
(1,'Non classé','non-classe',0),
 (2,'main','main',0),
 (8,'Plus d\'infos','plus-dinfos',0),
 (9,'Actualités','actualites',0),
 (11,'Boire et Manger','boire-et-manger',0),
 (12,'Sorties','sorties',0),
 (13,'Evénements','evenements',0),
 (14,'Ballades','ballades',0),
 (15,'Musées','musees',0),
 (16,'main 2','main-2',0),
 (17,'Propriété','propriete',0);

SET FOREIGN_KEY_CHECKS = 1 ; 
COMMIT ; 
SET AUTOCOMMIT = 1 ; 
