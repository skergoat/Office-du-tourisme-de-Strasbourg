-- ------------------------------------------------------
-- ------------------------------------------------------
--
-- WPBackItUp Database Export 
--
-- Created: 2019/11/12 on 02:29
--
-- Database : skergoat_wordpress
--
-- Backup   Table  : sk_litespeed_img_optm
-- Snapshot Table  : 1573529321_litespeed_img_optm
--
-- SQL    : SELECT * FROM sk_litespeed_img_optm LIMIT 0,10000
-- Offset : 0
-- Rows   : 0
-- ------------------------------------------------------
-- ------------------------------------------------------
SET AUTOCOMMIT = 0 ;
SET FOREIGN_KEY_CHECKS=0 ;

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40101 SET SESSION sql_mode = '' */;

--
-- Table structure for table `1573529321_litespeed_img_optm`
--
DROP TABLE  IF EXISTS `1573529321_litespeed_img_optm`;
CREATE TABLE `1573529321_litespeed_img_optm` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `optm_status` varchar(64) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `src` varchar(1000) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `srcpath_md5` varchar(128) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `src_md5` varchar(128) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `root_id` int(11) NOT NULL DEFAULT 0,
  `src_filesize` int(11) NOT NULL DEFAULT 0,
  `target_filesize` int(11) NOT NULL DEFAULT 0,
  `target_saved` int(11) NOT NULL DEFAULT 0,
  `webp_filesize` int(11) NOT NULL DEFAULT 0,
  `webp_saved` int(11) NOT NULL DEFAULT 0,
  `server_info` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `post_id_2` (`post_id`,`srcpath_md5`),
  KEY `post_id` (`post_id`),
  KEY `optm_status` (`optm_status`),
  KEY `root_id` (`root_id`),
  KEY `src_md5` (`src_md5`),
  KEY `srcpath_md5` (`srcpath_md5`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;



--
-- Data for table `sk_litespeed_img_optm`
-- Number of rows: 0
--
--
-- Data for table `sk_litespeed_img_optm`
-- Number of rows: 0
--
SET FOREIGN_KEY_CHECKS = 1 ; 
COMMIT ; 
SET AUTOCOMMIT = 1 ; 
