-- ------------------------------------------------------
-- ------------------------------------------------------
--
-- WPBackItUp Database Export 
--
-- Created: 2019/11/12 on 02:29
--
-- Database : skergoat_wordpress
--
-- Backup   Table  : sk_litespeed_optimizer
-- Snapshot Table  : 1573529321_litespeed_optimizer
--
-- SQL    : SELECT * FROM sk_litespeed_optimizer LIMIT 0,10000
-- Offset : 0
-- Rows   : 0
-- ------------------------------------------------------
-- ------------------------------------------------------
SET AUTOCOMMIT = 0 ;
SET FOREIGN_KEY_CHECKS=0 ;

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40101 SET SESSION sql_mode = '' */;

--
-- Table structure for table `1573529321_litespeed_optimizer`
--
DROP TABLE  IF EXISTS `1573529321_litespeed_optimizer`;
CREATE TABLE `1573529321_litespeed_optimizer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hash_name` varchar(60) COLLATE utf8mb4_unicode_520_ci NOT NULL COMMENT 'hash.filetype',
  `src` text COLLATE utf8mb4_unicode_520_ci NOT NULL COMMENT 'full url array set',
  `dateline` int(11) NOT NULL,
  `refer` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL COMMENT 'The container page url',
  PRIMARY KEY (`id`),
  UNIQUE KEY `hash_name` (`hash_name`),
  KEY `dateline` (`dateline`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;



--
-- Data for table `sk_litespeed_optimizer`
-- Number of rows: 0
--
--
-- Data for table `sk_litespeed_optimizer`
-- Number of rows: 0
--
SET FOREIGN_KEY_CHECKS = 1 ; 
COMMIT ; 
SET AUTOCOMMIT = 1 ; 
