-- ------------------------------------------------------
-- ------------------------------------------------------
--
-- WPBackItUp Database Export 
--
-- Created: 2019/11/12 on 02:29
--
-- Database : skergoat_wordpress
--
-- Backup   Table  : sk_nextend2_smartslider3_slides
-- Snapshot Table  : 1573529321_nextend2_smartslider3_slides
--
-- SQL    : SELECT * FROM sk_nextend2_smartslider3_slides LIMIT 0,10000
-- Offset : 0
-- Rows   : 42
-- ------------------------------------------------------
-- ------------------------------------------------------
SET AUTOCOMMIT = 0 ;
SET FOREIGN_KEY_CHECKS=0 ;

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40101 SET SESSION sql_mode = '' */;

--
-- Table structure for table `1573529321_nextend2_smartslider3_slides`
--
DROP TABLE  IF EXISTS `1573529321_nextend2_smartslider3_slides`;
CREATE TABLE `1573529321_nextend2_smartslider3_slides` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(200) NOT NULL,
  `slider` int(11) NOT NULL,
  `publish_up` datetime NOT NULL,
  `publish_down` datetime NOT NULL,
  `published` tinyint(1) NOT NULL,
  `first` int(11) NOT NULL,
  `slide` longtext DEFAULT NULL,
  `description` text NOT NULL,
  `thumbnail` varchar(255) NOT NULL,
  `params` text NOT NULL,
  `ordering` int(11) NOT NULL,
  `generator_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=146 DEFAULT CHARSET=utf8;



--
-- Data for table `sk_nextend2_smartslider3_slides`
-- Number of rows: 42
--
INSERT INTO `1573529321_nextend2_smartslider3_slides` VALUES 
(82,'musee-1-min',4,'2019-09-23 04:48:05','2029-09-24 04:48:05',1,0,'[]','','$upload$/2019/09/musee-1-min.jpg','{\"backgroundImage\":\"$upload$\\/2019\\/09\\/musee-1-min.jpg\",\"version\":\"3.3.22\"}',1,0),
 (83,'musee-2-min',4,'2019-09-23 04:48:05','2029-09-24 04:48:05',1,0,'[]','','$upload$/2019/09/musee-2-min.jpg','{\"backgroundImage\":\"$upload$\\/2019\\/09\\/musee-2-min.jpg\",\"version\":\"3.3.22\"}',2,0),
 (84,'musee-3-min',4,'2019-09-23 04:48:05','2029-09-24 04:48:05',1,0,'[]','','$upload$/2019/09/musee-3-min.jpg','{\"backgroundImage\":\"$upload$\\/2019\\/09\\/musee-3-min.jpg\",\"version\":\"3.3.22\"}',3,0),
 (85,'musee-4-min',4,'2019-09-23 04:48:05','2029-09-24 04:48:05',1,0,'[]','','$upload$/2019/09/musee-4-min.jpg','{\"backgroundImage\":\"$upload$\\/2019\\/09\\/musee-4-min.jpg\",\"version\":\"3.3.22\"}',4,0),
 (86,'musee-5-min',4,'2019-09-23 04:48:05','2029-09-24 04:48:05',1,0,'[]','','$upload$/2019/09/musee-5-min.jpg','{\"backgroundImage\":\"$upload$\\/2019\\/09\\/musee-5-min.jpg\",\"version\":\"3.3.22\"}',0,0),
 (87,'kammerzel-2-min',6,'2019-09-23 04:50:04','2029-09-24 04:50:04',1,0,'[]','','$upload$/2019/09/kammerzel-2-min.jpg','{\"backgroundImage\":\"$upload$\\/2019\\/09\\/kammerzel-2-min.jpg\",\"version\":\"3.3.22\"}',0,0),
 (88,'kammerzel-3-min',6,'2019-09-23 04:50:04','2029-09-24 04:50:04',1,0,'[]','','$upload$/2019/09/kammerzel-3-min.jpg','{\"backgroundImage\":\"$upload$\\/2019\\/09\\/kammerzel-3-min.jpg\",\"version\":\"3.3.22\"}',1,0),
 (89,'kammerzel-4-min',6,'2019-09-23 04:50:04','2029-09-24 04:50:04',1,0,'[]','','$upload$/2019/09/kammerzel-4-min.jpg','{\"backgroundImage\":\"$upload$\\/2019\\/09\\/kammerzel-4-min.jpg\",\"version\":\"3.3.22\"}',2,0),
 (90,'kammerzel-5-min',6,'2019-09-23 04:50:04','2029-09-24 04:50:04',1,0,'[]','','$upload$/2019/09/kammerzel-5-min.jpg','{\"backgroundImage\":\"$upload$\\/2019\\/09\\/kammerzel-5-min.jpg\",\"version\":\"3.3.22\"}',3,0),
 (91,'223007616_7-min',5,'2019-09-23 04:52:15','2029-09-24 04:52:15',1,0,'[]','','$upload$/2019/09/223007616_7-min.jpg','{\"backgroundImage\":\"$upload$\\/2019\\/09\\/223007616_7-min.jpg\",\"version\":\"3.3.22\"}',0,0),
 (92,'Canaux-Strasbourg-min',5,'2019-09-23 04:52:15','2029-09-24 04:52:15',1,0,'[]','','$upload$/2019/09/Canaux-Strasbourg-min.jpg','{\"backgroundImage\":\"$upload$\\/2019\\/09\\/Canaux-Strasbourg-min.jpg\",\"version\":\"3.3.22\"}',1,0),
 (93,'colmar-min',5,'2019-09-23 04:52:15','2029-09-24 04:52:15',1,0,'[]','','$upload$/2019/09/colmar-min.jpg','{\"backgroundImage\":\"$upload$\\/2019\\/09\\/colmar-min.jpg\",\"version\":\"3.3.22\"}',2,0),
 (94,'Notre-Dame_de_Strasbourg_©-Claude-Truong-Ngoc-min',8,'2019-09-23 04:54:07','2029-09-24 04:54:07',1,0,'[]','','$upload$/2019/09/Notre-Dame_de_Strasbourg_©-Claude-Truong-Ngoc-min.jpg','{\"backgroundImage\":\"$upload$\\/2019\\/09\\/Notre-Dame_de_Strasbourg_\\u00a9-Claude-Truong-Ngoc-min.jpg\",\"version\":\"3.3.22\"}',0,0),
 (95,'modern-noel-1-min',8,'2019-09-23 04:54:07','2029-09-24 04:54:07',1,0,'[]','','$upload$/2019/09/modern-noel-1-min.jpeg','{\"backgroundImage\":\"$upload$\\/2019\\/09\\/modern-noel-1-min.jpeg\",\"version\":\"3.3.22\"}',1,0),
 (96,'les-plus-belles-peintures-3-strasbourg-en-233t233-i-portfolio-de-mandy-guilbert-1920x1080-768x432-min',5,'2019-09-23 04:54:25','2029-09-24 04:54:25',1,0,'[]','','$upload$/2019/09/les-plus-belles-peintures-3-strasbourg-en-233t233-i-portfolio-de-mandy-guilbert-1920x1080-768x432-min.jpg','{\"backgroundImage\":\"$upload$\\/2019\\/09\\/les-plus-belles-peintures-3-strasbourg-en-233t233-i-portfolio-de-mandy-guilbert-1920x1080-768x432-min.jpg\",\"version\":\"3.3.22\"}',3,0),
 (97,'petite-france-strasbourg-min',5,'2019-09-23 04:54:25','2029-09-24 04:54:25',1,0,'[]','','$upload$/2019/09/petite-france-strasbourg-min.jpg','{\"backgroundImage\":\"$upload$\\/2019\\/09\\/petite-france-strasbourg-min.jpg\",\"version\":\"3.3.22\"}',4,0),
 (98,'estampe-1-min',7,'2019-09-23 04:56:06','2029-09-24 04:56:06',1,0,'[]','','$upload$/2019/09/estampe-1-min.jpg','{\"backgroundImage\":\"$upload$\\/2019\\/09\\/estampe-1-min.jpg\",\"version\":\"3.3.22\"}',1,0),
 (99,'estampe-3-min',7,'2019-09-23 04:56:06','2029-09-24 04:56:06',1,0,'[]','','$upload$/2019/09/estampe-3-min.jpg','{\"backgroundImage\":\"$upload$\\/2019\\/09\\/estampe-3-min.jpg\",\"version\":\"3.3.22\"}',2,0),
 (100,'estampe-5-min',7,'2019-09-23 04:56:06','2029-09-24 04:56:06',1,0,'[]','','$upload$/2019/09/estampe-5-min.jpg','{\"backgroundImage\":\"$upload$\\/2019\\/09\\/estampe-5-min.jpg\",\"version\":\"3.3.22\"}',3,0),
 (101,'estampes-5-min',7,'2019-09-23 04:56:06','2029-09-24 04:56:06',1,0,'[]','','$upload$/2019/09/estampes-5-min.jpg','{\"backgroundImage\":\"$upload$\\/2019\\/09\\/estampes-5-min.jpg\",\"version\":\"3.3.22\"}',4,0),
 (102,'estampes-6-min',7,'2019-09-23 04:56:06','2029-09-24 04:56:06',1,0,'[]','','$upload$/2019/09/estampes-6-min.jpg','{\"backgroundImage\":\"$upload$\\/2019\\/09\\/estampes-6-min.jpg\",\"version\":\"3.3.22\"}',0,0),
 (103,'vauban-1-min',3,'2019-09-23 05:01:25','2029-09-24 05:01:25',1,0,'[]','','$upload$/2019/09/vauban-1-min.jpg','{\"backgroundImage\":\"$upload$\\/2019\\/09\\/vauban-1-min.jpg\",\"version\":\"3.3.22\"}',0,0),
 (104,'vauban-2-min',3,'2019-09-23 05:01:25','2029-09-24 05:01:25',1,0,'[]','','$upload$/2019/09/vauban-2-min.jpg','{\"backgroundImage\":\"$upload$\\/2019\\/09\\/vauban-2-min.jpg\",\"version\":\"3.3.22\"}',1,0),
 (105,'vauban-3-min',3,'2019-09-23 05:01:25','2029-09-24 05:01:25',1,0,'[]','','$upload$/2019/09/vauban-3-min.jpg','{\"backgroundImage\":\"$upload$\\/2019\\/09\\/vauban-3-min.jpg\",\"version\":\"3.3.22\"}',2,0),
 (109,'sainte-croix-1-min',10,'2019-09-23 05:52:17','2029-09-24 05:52:17',1,0,'[]','','$upload$/2019/09/sainte-croix-1-min.jpg','{\"backgroundImage\":\"$upload$\\/2019\\/09\\/sainte-croix-1-min.jpg\",\"version\":\"3.3.22\"}',0,0),
 (110,'sainte-croix-2-min',10,'2019-09-23 05:55:05','2029-09-24 05:55:05',1,0,'[]','','$upload$/2019/09/sainte-croix-2-min.jpg','{\"backgroundImage\":\"$upload$\\/2019\\/09\\/sainte-croix-2-min.jpg\",\"version\":\"3.3.22\"}',1,0),
 (116,'sainte-croix-1-min',11,'2019-09-23 05:56:11','2029-09-24 05:56:11',1,0,'[]','','$upload$/2019/09/sainte-croix-1-min.jpg','{\"backgroundImage\":\"$upload$\\/2019\\/09\\/sainte-croix-1-min.jpg\",\"version\":\"3.3.22\"}',0,0),
 (117,'sainte-croix-2-min',11,'2019-09-23 05:56:11','2029-09-24 05:56:11',1,0,'[]','','$upload$/2019/09/sainte-croix-2-min.jpg','{\"backgroundImage\":\"$upload$\\/2019\\/09\\/sainte-croix-2-min.jpg\",\"version\":\"3.3.22\"}',1,0),
 (118,'sainte-croix-3-min',11,'2019-09-23 05:58:02','2029-09-24 05:58:02',1,0,'[]','','$upload$/2019/09/sainte-croix-3-min.jpg','{\"backgroundImage\":\"$upload$\\/2019\\/09\\/sainte-croix-3-min.jpg\",\"version\":\"3.3.22\"}',2,0),
 (122,'cabane-1-min',12,'2019-09-23 06:03:09','2029-09-24 06:03:09',1,0,'[]','','$upload$/2019/09/cabane-1-min.jpg','{\"backgroundImage\":\"$upload$\\/2019\\/09\\/cabane-1-min.jpg\",\"version\":\"3.3.22\"}',0,0),
 (123,'cabane-2-min',12,'2019-09-23 06:03:10','2029-09-24 06:03:10',1,0,'[]','','$upload$/2019/09/cabane-2-min.jpg','{\"backgroundImage\":\"$upload$\\/2019\\/09\\/cabane-2-min.jpg\",\"version\":\"3.3.22\"}',1,0),
 (124,'cabane-4-min',12,'2019-09-23 06:05:50','2029-09-24 06:05:50',1,0,'[]','','$upload$/2019/09/cabane-4-min.jpg','{\"backgroundImage\":\"$upload$\\/2019\\/09\\/cabane-4-min.jpg\",\"version\":\"3.3.22\"}',2,0),
 (129,'manadala-2-min',13,'2019-09-23 07:12:21','2029-09-24 07:12:21',1,0,'[]','','$upload$/2019/09/manadala-2-min.jpg','{\"backgroundImage\":\"$upload$\\/2019\\/09\\/manadala-2-min.jpg\",\"version\":\"3.3.22\"}',0,0),
 (131,'natura-1-min',14,'2019-09-23 07:16:17','2029-09-24 07:16:17',1,0,'[]','','$upload$/2019/09/natura-1-min.jpg','{\"backgroundImage\":\"$upload$\\/2019\\/09\\/natura-1-min.jpg\",\"version\":\"3.3.22\"}',1,0),
 (132,'natura-2-min',14,'2019-09-23 07:16:17','2029-09-24 07:16:17',1,0,'[]','','$upload$/2019/09/natura-2-min.jpg','{\"backgroundImage\":\"$upload$\\/2019\\/09\\/natura-2-min.jpg\",\"version\":\"3.3.22\"}',2,0),
 (133,'natura-3-min',14,'2019-09-23 07:16:17','2029-09-24 07:16:17',1,0,'[]','','$upload$/2019/09/natura-3-min.jpg','{\"backgroundImage\":\"$upload$\\/2019\\/09\\/natura-3-min.jpg\",\"version\":\"3.3.22\"}',0,0),
 (137,'saint-jean-1-min',15,'2019-09-23 07:22:06','2029-09-24 07:22:06',1,0,'[]','','$upload$/2019/09/saint-jean-1-min.jpg','{\"backgroundImage\":\"$upload$\\/2019\\/09\\/saint-jean-1-min.jpg\",\"version\":\"3.3.22\"}',0,0),
 (138,'saint-jean-2-min',15,'2019-09-23 07:22:06','2029-09-24 07:22:06',1,0,'[]','','$upload$/2019/09/saint-jean-2-min.jpg','{\"backgroundImage\":\"$upload$\\/2019\\/09\\/saint-jean-2-min.jpg\",\"version\":\"3.3.22\"}',1,0),
 (139,'saint-jean-3-min',15,'2019-09-23 07:22:06','2029-09-24 07:22:06',1,0,'[]','','$upload$/2019/09/saint-jean-3-min.jpg','{\"backgroundImage\":\"$upload$\\/2019\\/09\\/saint-jean-3-min.jpg\",\"version\":\"3.3.22\"}',2,0),
 (143,'fete-1-min',16,'2019-09-23 07:29:16','2029-09-24 07:29:16',1,0,'[]','','$upload$/2019/09/fete-1-min.jpg','{\"backgroundImage\":\"$upload$\\/2019\\/09\\/fete-1-min.jpg\",\"version\":\"3.3.22\"}',0,0),
 (144,'fete-2-min',16,'2019-09-23 07:29:16','2029-09-24 07:29:16',1,0,'[]','','$upload$/2019/09/fete-2-min.jpg','{\"backgroundImage\":\"$upload$\\/2019\\/09\\/fete-2-min.jpg\",\"version\":\"3.3.22\"}',1,0),
 (145,'fete-3-min',16,'2019-09-23 07:29:16','2029-09-24 07:29:16',1,0,'[]','','$upload$/2019/09/fete-3-min.jpg','{\"backgroundImage\":\"$upload$\\/2019\\/09\\/fete-3-min.jpg\",\"version\":\"3.3.22\"}',2,0);

SET FOREIGN_KEY_CHECKS = 1 ; 
COMMIT ; 
SET AUTOCOMMIT = 1 ; 
