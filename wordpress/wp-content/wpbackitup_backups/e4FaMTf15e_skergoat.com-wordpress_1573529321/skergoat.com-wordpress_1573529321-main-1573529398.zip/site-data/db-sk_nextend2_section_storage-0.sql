-- ------------------------------------------------------
-- ------------------------------------------------------
--
-- WPBackItUp Database Export 
--
-- Created: 2019/11/12 on 02:29
--
-- Database : skergoat_wordpress
--
-- Backup   Table  : sk_nextend2_section_storage
-- Snapshot Table  : 1573529321_nextend2_section_storage
--
-- SQL    : SELECT * FROM sk_nextend2_section_storage LIMIT 0,10000
-- Offset : 0
-- Rows   : 6
-- ------------------------------------------------------
-- ------------------------------------------------------
SET AUTOCOMMIT = 0 ;
SET FOREIGN_KEY_CHECKS=0 ;

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40101 SET SESSION sql_mode = '' */;

--
-- Table structure for table `1573529321_nextend2_section_storage`
--
DROP TABLE  IF EXISTS `1573529321_nextend2_section_storage`;
CREATE TABLE `1573529321_nextend2_section_storage` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `application` varchar(20) NOT NULL,
  `section` varchar(128) NOT NULL,
  `referencekey` varchar(128) NOT NULL,
  `value` mediumtext NOT NULL,
  `system` int(11) NOT NULL DEFAULT 0,
  `editable` int(11) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `application` (`application`,`section`,`referencekey`),
  KEY `application_2` (`application`,`section`)
) ENGINE=InnoDB AUTO_INCREMENT=13171 DEFAULT CHARSET=utf8;



--
-- Data for table `sk_nextend2_section_storage`
-- Number of rows: 6
--
INSERT INTO `1573529321_nextend2_section_storage` VALUES 
(10000,'system','global','n2_ss3_version','3.3.22r4878',1,1),
 (10002,'system','style','1900','eyJuYW1lIjoic3RyYXNib3VyZyIsImRhdGEiOlt7ImJhY2tncm91bmRjb2xvciI6ImZmZmZmZjAwIiwib3BhY2l0eSI6MTAwLCJwYWRkaW5nIjoiMHwqfDB8KnwwfCp8MHwqfHB4IiwiYm94c2hhZG93IjoiMHwqfDB8KnwwfCp8MHwqfDAwMDAwMGZmIiwiYm9yZGVyIjoiMHwqfHNvbGlkfCp8MDAwMDAwZmYiLCJib3JkZXJyYWRpdXMiOiIwIiwiZXh0cmEiOiIifSx7ImV4dHJhIjoiIiwiYm9yZGVyIjoiMHwqfHNvbGlkfCp8ZDg1OTM1ZmYifV19',0,1),
 (10007,'system','style','1900','eyJuYW1lIjoic3RyYXNib3VyZyAyIiwiZGF0YSI6W3siYmFja2dyb3VuZGNvbG9yIjoiMDAwMDAwODAiLCJvcGFjaXR5IjoxMDAsInBhZGRpbmciOiIwfCp8MHwqfDB8KnwwfCp8cHgiLCJib3hzaGFkb3ciOiIwfCp8MHwqfDB8KnwwfCp8MDAwMDAwZmYiLCJib3JkZXIiOiIwfCp8c29saWR8KnwwMDAwMDBmZiIsImJvcmRlcnJhZGl1cyI6IjAiLCJleHRyYSI6IiJ9LHsiZXh0cmEiOiIiLCJib3JkZXIiOiIwfCp8c29saWR8KnxkODU5MzVmZiIsImJhY2tncm91bmRjb2xvciI6ImQ4NTkzNWZmIn1dfQ==',0,1),
 (10467,'smartslider','tutorial','free','1',0,1),
 (10624,'smartslider','free','review','1',0,1),
 (10706,'smartslider','free','promoUpgrade','1',0,1);

SET FOREIGN_KEY_CHECKS = 1 ; 
COMMIT ; 
SET AUTOCOMMIT = 1 ; 
