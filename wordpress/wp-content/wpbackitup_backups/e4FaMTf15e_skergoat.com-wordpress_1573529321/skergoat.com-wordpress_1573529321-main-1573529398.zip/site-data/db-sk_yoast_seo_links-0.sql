-- ------------------------------------------------------
-- ------------------------------------------------------
--
-- WPBackItUp Database Export 
--
-- Created: 2019/11/12 on 02:29
--
-- Database : skergoat_wordpress
--
-- Backup   Table  : sk_yoast_seo_links
-- Snapshot Table  : 1573529321_yoast_seo_links
--
-- SQL    : SELECT * FROM sk_yoast_seo_links LIMIT 0,10000
-- Offset : 0
-- Rows   : 61
-- ------------------------------------------------------
-- ------------------------------------------------------
SET AUTOCOMMIT = 0 ;
SET FOREIGN_KEY_CHECKS=0 ;

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40101 SET SESSION sql_mode = '' */;

--
-- Table structure for table `1573529321_yoast_seo_links`
--
DROP TABLE  IF EXISTS `1573529321_yoast_seo_links`;
CREATE TABLE `1573529321_yoast_seo_links` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `url` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_id` bigint(20) unsigned NOT NULL,
  `target_post_id` bigint(20) unsigned NOT NULL,
  `type` varchar(8) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `link_direction` (`post_id`,`type`)
) ENGINE=InnoDB AUTO_INCREMENT=1195 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



--
-- Data for table `sk_yoast_seo_links`
-- Number of rows: 61
--
INSERT INTO `1573529321_yoast_seo_links` VALUES 
(726,'http://www.cathedrale-strasbourg.fr/plan-dacces-et-horaires',227,0,'external'),
 (863,'#',221,0,'internal'),
 (864,'#',221,0,'internal'),
 (865,'#',221,0,'internal'),
 (866,'#',221,0,'internal'),
 (867,'#',221,0,'internal'),
 (868,'#',221,0,'internal'),
 (869,'#',221,0,'internal'),
 (870,'#',221,0,'internal'),
 (881,'https://fr-fr.facebook.com/la.cabane.chalon/',219,0,'external'),
 (882,'lacabane@gmail.com',219,0,'internal'),
 (893,'https://fr-fr.facebook.com/mandala.strasbourg/',217,0,'external'),
 (894,'mandala@gmail.com',217,0,'internal'),
 (1086,'http://www.strasbourg.eu/',1010,0,'external'),
 (1087,'http://www.strasbourg.eu/',1010,0,'external'),
 (1088,'http://www.europtimist.eu/',1010,0,'external'),
 (1089,'http://www.europtimist.eu/',1010,0,'external'),
 (1090,'http://www.tourisme67.com/',1010,0,'external'),
 (1091,'http://www.tourisme67.com/',1010,0,'external'),
 (1092,'http://www.visit.alsace/',1010,0,'external'),
 (1093,'http://www.archi-strasbourg.org/',1010,0,'external'),
 (1094,'http://www.archi-strasbourg.org/',1010,0,'external'),
 (1110,'http://www.otstrasbourg.fr/',1008,0,'external'),
 (1111,'mailto:info@otstrasbourg.fr',1008,0,'external'),
 (1112,'http://www.dnconsultants.fr/',1008,0,'external'),
 (1113,'mailto:rgpd@otstrasbourg.fr',1008,0,'external'),
 (1114,'http://www.cnil.fr/',1008,0,'external'),
 (1142,'https://skergoat.com/wordpress/activites-du-mois-a-strasbourg/',359,14,'internal'),
 (1143,'https://skergoat.com/wordpress/liens-utiles/',359,1010,'internal'),
 (1144,'https://skergoat.com/wordpress/mentions-legales/',359,1008,'internal'),
 (1145,'https://skergoat.com/wordpress/',359,5,'internal'),
 (1146,'https://skergoat.com/wordpress/actualites-de-la-ville-de-strasbourg/',359,0,'internal'),
 (1147,'https://skergoat.com/wordpress/plus-dinfos-sur-la-ville-de-strasbourg/',359,12,'internal'),
 (1148,'https://skergoat.com/wordpress/contact/',359,16,'internal'),
 (1149,'https://skergoat.com/wordpress/category/actualites/',359,0,'internal'),
 (1150,'https://skergoat.com/wordpress/2018/07/03/la-foire-saint-jean-lattraction-des-petits-et-des-grands/',359,240,'internal'),
 (1151,'https://skergoat.com/wordpress/2018/07/03/natura-parc-aventure-a-la-cime-des-arbres/',359,237,'internal'),
 (1152,'https://skergoat.com/wordpress/2018/07/03/evasion-dans-la-nature-au-parc-de-sainte-croix/',359,223,'internal'),
 (1153,'https://skergoat.com/wordpress/2018/07/03/fete-de-la-musique-a-strasbourg-coups-de-coeur/',359,221,'internal'),
 (1154,'https://skergoat.com/wordpress/2018/07/03/un-nouveau-bar-branche-du-centre-ville/',359,219,'internal'),
 (1155,'https://skergoat.com/wordpress/2018/07/03/restaurant-mandala-a-strasbourg/',359,217,'internal'),
 (1156,'https://skergoat.com/wordpress/category/actualites/boire-et-manger/',359,0,'internal'),
 (1157,'https://skergoat.com/wordpress/category/actualites/evenements/',359,0,'internal'),
 (1158,'https://skergoat.com/wordpress/category/actualites/sorties/',359,0,'internal'),
 (1159,'https://skergoat.com/wordpress/category/plus-dinfos/',359,0,'internal'),
 (1160,'https://skergoat.com/wordpress/category/plus-dinfos/ballades/',359,0,'internal'),
 (1161,'https://skergoat.com/wordpress/2018/07/03/le-barrage-vauban/',359,233,'internal'),
 (1162,'https://skergoat.com/wordpress/2018/07/03/charme-de-la-petite-france/',359,229,'internal'),
 (1163,'https://skergoat.com/wordpress/2018/07/03/la-cathedrale-notre-dame/',359,227,'internal'),
 (1164,'https://skergoat.com/wordpress/category/plus-dinfos/musees/',359,0,'internal'),
 (1165,'https://skergoat.com/wordpress/2018/07/03/musee-des-estampes-de-strasbourg/',359,235,'internal'),
 (1166,'https://skergoat.com/wordpress/2018/07/03/visite-au-musee-alsacien/',359,231,'internal'),
 (1167,'https://skergoat.com/wordpress/2018/07/03/la-maison-kammerzell/',359,225,'internal'),
 (1168,'https://skergoat.com/wordpress/?post_type=popup&p=344',359,344,'internal'),
 (1178,'https://skergoat.com/wordpress/wp-content/uploads/2019/09/logo-rouge.jpg',16,0,'internal'),
 (1179,'https://fr-fr.facebook.com/StrasbourgTourisme/',16,0,'external'),
 (1180,'ocstrasbourg@gmail.com',16,0,'internal'),
 (1184,'https://www.jds.fr/strasbourg/quartier-remarquable/ponts-couverts-de-strasbourg-5073_L',229,0,'external'),
 (1185,'https://www.jds.fr/strasbourg/musee/musee-d-art-moderne-et-contemporain-mamcs-3359_L',229,0,'external'),
 (1186,'https://www.jds.fr/strasbourg/place/place-kleber-7281_L',229,0,'external'),
 (1194,'https://skergoat.com/wordpress/wp-content/uploads/2019/09/logo-rouge.jpg',1032,0,'internal');

SET FOREIGN_KEY_CHECKS = 1 ; 
COMMIT ; 
SET AUTOCOMMIT = 1 ; 
