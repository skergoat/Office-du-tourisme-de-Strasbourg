-- ------------------------------------------------------
-- ------------------------------------------------------
--
-- WPBackItUp Database Export 
--
-- Created: 2019/11/12 on 02:29
--
-- Database : skergoat_wordpress
--
-- Backup   Table  : sk_nextend2_smartslider3_sliders_xref
-- Snapshot Table  : 1573529321_nextend2_smartslider3_sliders_xref
--
-- SQL    : SELECT * FROM sk_nextend2_smartslider3_sliders_xref LIMIT 0,10000
-- Offset : 0
-- Rows   : 7
-- ------------------------------------------------------
-- ------------------------------------------------------
SET AUTOCOMMIT = 0 ;
SET FOREIGN_KEY_CHECKS=0 ;

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40101 SET SESSION sql_mode = '' */;

--
-- Table structure for table `1573529321_nextend2_smartslider3_sliders_xref`
--
DROP TABLE  IF EXISTS `1573529321_nextend2_smartslider3_sliders_xref`;
CREATE TABLE `1573529321_nextend2_smartslider3_sliders_xref` (
  `group_id` int(11) NOT NULL,
  `slider_id` int(11) NOT NULL,
  `ordering` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`group_id`,`slider_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



--
-- Data for table `sk_nextend2_smartslider3_sliders_xref`
-- Number of rows: 7
--
INSERT INTO `1573529321_nextend2_smartslider3_sliders_xref` VALUES 
(0,3,1),
 (0,4,2),
 (0,5,3),
 (0,6,4),
 (0,7,5),
 (0,8,6),
 (0,10,7);

SET FOREIGN_KEY_CHECKS = 1 ; 
COMMIT ; 
SET AUTOCOMMIT = 1 ; 
