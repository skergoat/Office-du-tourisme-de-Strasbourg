-- ------------------------------------------------------
-- ------------------------------------------------------
--
-- WPBackItUp Database Export 
--
-- Created: 2019/11/12 on 02:29
--
-- Database : skergoat_wordpress
--
-- Backup   Table  : sk_supsystic_tbl_tables
-- Snapshot Table  : 1573529321_supsystic_tbl_tables
--
-- SQL    : SELECT * FROM sk_supsystic_tbl_tables LIMIT 0,10000
-- Offset : 0
-- Rows   : 1
-- ------------------------------------------------------
-- ------------------------------------------------------
SET AUTOCOMMIT = 0 ;
SET FOREIGN_KEY_CHECKS=0 ;

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40101 SET SESSION sql_mode = '' */;

--
-- Table structure for table `1573529321_supsystic_tbl_tables`
--
DROP TABLE  IF EXISTS `1573529321_supsystic_tbl_tables`;
CREATE TABLE `1573529321_supsystic_tbl_tables` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `meta` text DEFAULT NULL,
  `settings` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;



--
-- Data for table `sk_supsystic_tbl_tables`
-- Number of rows: 1
--
INSERT INTO `1573529321_supsystic_tbl_tables` VALUES 
(1,'activite du mois','2018-07-04 10:15:16','a:7:{s:14:&quot;requiredAssets&quot;;a:0:{}s:11:&quot;mergedCells&quot;;a:0:{}s:12:&quot;columnsWidth&quot;;a:5:{i:0;i:62;i:1;i:62;i:2;i:62;i:3;i:62;i:4;i:62;}s:17:&quot;columnsFixedWidth&quot;;a:0:{}s:16:&quot;columnsSortOrder&quot;;a:0:{}s:21:&quot;columnsDisableSorting&quot;;a:0:{}s:3:&quot;css&quot;;s:340:&quot;/* Here you can add custom CSS for the current table */\n/* Lean more about CSS: https://en.wikipedia.org/wiki/Cascading_Style_Sheets */\n/*\nTo prevent the use of styles to other tables use &quot;#supsystic-table-5&quot; as a base selector\nfor example:\n#supsystic-table-5 { ... }\n#supsystic-table-5 tbody { ... }\n#supsystic-table-5 tbody tr { ... }\n*/\n&quot;;}','a:27:{s:8:&quot;elements&quot;;a:2:{s:15:&quot;descriptionText&quot;;s:0:&quot;&quot;;s:13:&quot;signatureText&quot;;s:0:&quot;&quot;;}s:15:&quot;headerRowsCount&quot;;s:1:&quot;1&quot;;s:15:&quot;footerRowsCount&quot;;s:1:&quot;1&quot;;s:11:&quot;fixedHeight&quot;;s:3:&quot;400&quot;;s:21:&quot;fixedLeftColumnsCount&quot;;s:1:&quot;1&quot;;s:22:&quot;fixedRightColumnsCount&quot;;s:1:&quot;0&quot;;s:9:&quot;autoIndex&quot;;s:3:&quot;off&quot;;s:12:&quot;numberFormat&quot;;s:8:&quot;1,000.00&quot;;s:14:&quot;currencyFormat&quot;;s:9:&quot;$1,000.00&quot;;s:13:&quot;percentFormat&quot;;s:6:&quot;10.00%&quot;;s:10:&quot;dateFormat&quot;;s:10:&quot;DD.MM.YYYY&quot;;s:18:&quot;timeDurationFormat&quot;;s:5:&quot;HH:mm&quot;;s:14:&quot;responsiveMode&quot;;s:1:&quot;1&quot;;s:12:&quot;sortingOrder&quot;;s:3:&quot;asc&quot;;s:18:&quot;sortingOrderColumn&quot;;s:1:&quot;1&quot;;s:20:&quot;paginationMenuLength&quot;;s:10:&quot;50,100,All&quot;;s:14:&quot;paginationSize&quot;;s:16:&quot;pagination-large&quot;;s:9:&quot;searching&quot;;a:2:{s:20:&quot;columnSearchPosition&quot;;s:6:&quot;bottom&quot;;s:8:&quot;minChars&quot;;s:1:&quot;0&quot;;}s:8:&quot;features&quot;;a:1:{s:25:&quot;after_table_loaded_script&quot;;s:0:&quot;&quot;;}s:10:&quot;tableWidth&quot;;s:3:&quot;100&quot;;s:14:&quot;tableWidthType&quot;;s:1:&quot;%&quot;;s:16:&quot;tableWidthMobile&quot;;s:3:&quot;100&quot;;s:20:&quot;tableWidthMobileType&quot;;s:1:&quot;%&quot;;s:7:&quot;styling&quot;;a:2:{s:6:&quot;border&quot;;s:11:&quot;cell-border&quot;;s:5:&quot;hover&quot;;s:2:&quot;on&quot;;}s:11:&quot;tableLoader&quot;;a:3:{s:8:&quot;iconName&quot;;s:7:&quot;default&quot;;s:9:&quot;iconItems&quot;;s:1:&quot;0&quot;;s:5:&quot;color&quot;;s:7:&quot;#000000&quot;;}s:6:&quot;styles&quot;;a:21:{s:9:&quot;customCss&quot;;s:0:&quot;&quot;;s:19:&quot;externalBorderColor&quot;;s:0:&quot;&quot;;s:19:&quot;externalBorderWidth&quot;;s:0:&quot;&quot;;s:17:&quot;headerBorderColor&quot;;s:0:&quot;&quot;;s:17:&quot;headerBorderWidth&quot;;s:0:&quot;&quot;;s:14:&quot;rowBorderColor&quot;;s:0:&quot;&quot;;s:14:&quot;rowBorderWidth&quot;;s:0:&quot;&quot;;s:17:&quot;columnBorderColor&quot;;s:0:&quot;&quot;;s:17:&quot;columnBorderWidth&quot;;s:0:&quot;&quot;;s:21:&quot;headerBackgroundColor&quot;;s:0:&quot;&quot;;s:15:&quot;headerFontColor&quot;;s:0:&quot;&quot;;s:14:&quot;headerFontSize&quot;;s:0:&quot;&quot;;s:19:&quot;cellBackgroundColor&quot;;s:0:&quot;&quot;;s:13:&quot;cellFontColor&quot;;s:0:&quot;&quot;;s:12:&quot;cellFontSize&quot;;s:0:&quot;&quot;;s:21:&quot;searchBackgroundColor&quot;;s:0:&quot;&quot;;s:15:&quot;searchFontColor&quot;;s:0:&quot;&quot;;s:17:&quot;searchBorderColor&quot;;s:0:&quot;&quot;;s:17:&quot;verticalAlignment&quot;;s:0:&quot;&quot;;s:19:&quot;horizontalAlignment&quot;;s:0:&quot;&quot;;s:18:&quot;paginationPosition&quot;;s:0:&quot;&quot;;}s:8:&quot;language&quot;;a:9:{s:10:&quot;emptyTable&quot;;s:0:&quot;&quot;;s:4:&quot;info&quot;;s:0:&quot;&quot;;s:9:&quot;infoEmpty&quot;;s:0:&quot;&quot;;s:12:&quot;infoFiltered&quot;;s:0:&quot;&quot;;s:10:&quot;lengthMenu&quot;;s:0:&quot;&quot;;s:6:&quot;search&quot;;s:0:&quot;&quot;;s:11:&quot;zeroRecords&quot;;s:0:&quot;&quot;;s:11:&quot;exportLabel&quot;;s:0:&quot;&quot;;s:4:&quot;file&quot;;s:7:&quot;default&quot;;}}');

SET FOREIGN_KEY_CHECKS = 1 ; 
COMMIT ; 
SET AUTOCOMMIT = 1 ; 
