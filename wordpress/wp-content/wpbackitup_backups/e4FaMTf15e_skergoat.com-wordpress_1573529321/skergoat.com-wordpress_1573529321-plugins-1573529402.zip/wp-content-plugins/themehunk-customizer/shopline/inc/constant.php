<?php
define('SHOPLINE_SLIDER', get_parent_theme_file_uri('/images/main.jpeg'));
define('SHOPLINE_LARGE', THEMEHUNK_CUSTOMIZER_PLUGIN_URL.'/themehunk/images/lrg.png');
define('SHOPLINE_SMALL', THEMEHUNK_CUSTOMIZER_PLUGIN_URL.'/themehunk/images/sml.png');
define('SHOPLINE_TESTIMONIAL', THEMEHUNK_CUSTOMIZER_PLUGIN_URL.'/oneline-lite/images/testimonia.png');
define('SHOPLINE_GRADIENT_DFLT_IMAGE', THEMEHUNK_CUSTOMIZER_PLUGIN_URL. "themehunk/customizer-radio-image/img/gradient-1.png");
define('SHOPLINE_GRADIENT_ONE_IMAGE', THEMEHUNK_CUSTOMIZER_PLUGIN_URL. "themehunk/customizer-radio-image/img/gradient-3.png");
define('SHOPLINE_GRADIENT_TWO_IMAGE', THEMEHUNK_CUSTOMIZER_PLUGIN_URL. "themehunk/customizer-radio-image/img/gradient-2.png");

define('SHOPLINE_GRADIENT_OVLY_ONE_IMAGE', THEMEHUNK_CUSTOMIZER_PLUGIN_URL. "themehunk/customizer-radio-image/img/gradientovly-1.png");
define('SHOPLINE_GRADIENT_OVLY_TWO_IMAGE', THEMEHUNK_CUSTOMIZER_PLUGIN_URL. "themehunk/customizer-radio-image/img/gradientovly-2.png");
define('SHOPLINE_GRADIENT_OVLY_THREE_IMAGE', THEMEHUNK_CUSTOMIZER_PLUGIN_URL. "themehunk/customizer-radio-image/img/gradientovly-3.png");
define('SHOPLINE_GRADIENT_OVLY_FOUR_IMAGE', THEMEHUNK_CUSTOMIZER_PLUGIN_URL. "themehunk/customizer-radio-image/img/gradientovly-4.png");
define('SHOPLINE_GRADIENT_OVLY_FIVE_IMAGE', THEMEHUNK_CUSTOMIZER_PLUGIN_URL. "themehunk/customizer-radio-image/img/gradientovly-5.png");
define('SHOPLINE_GRADIENT_OVLY_SIX_IMAGE', THEMEHUNK_CUSTOMIZER_PLUGIN_URL. "themehunk/customizer-radio-image/img/gradientovly-6.png");
define('SHOPLINE_SVG_IMG1', THEMEHUNK_CUSTOMIZER_PLUGIN_URL. "themehunk/customizer-radio-image/img/svg1.jpg");
define('SHOPLINE_SVG_IMG2', THEMEHUNK_CUSTOMIZER_PLUGIN_URL. "themehunk/customizer-radio-image/img/svg2.jpg");