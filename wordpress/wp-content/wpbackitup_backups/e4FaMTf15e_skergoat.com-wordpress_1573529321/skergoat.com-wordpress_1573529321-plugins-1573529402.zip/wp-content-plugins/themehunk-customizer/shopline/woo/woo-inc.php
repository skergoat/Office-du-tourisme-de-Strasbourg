<?php
require_once( plugin_dir_path(__FILE__) . '/woocommerce.php' );
require_once( plugin_dir_path(__FILE__) . '/filter-woocommerce.php' );
require_once( plugin_dir_path(__FILE__) . '/hooks-function.php' );
require_once( plugin_dir_path(__FILE__) . '/hooks.php' );
require_once( plugin_dir_path(__FILE__) . '/ajax-woocommerce.php' );
?>