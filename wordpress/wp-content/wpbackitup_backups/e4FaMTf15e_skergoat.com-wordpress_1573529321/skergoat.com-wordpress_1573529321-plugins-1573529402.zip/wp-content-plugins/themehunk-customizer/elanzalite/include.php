<?php
	include_once( plugin_dir_path(__FILE__) . 'inc/constant.php' );
	include_once( plugin_dir_path(__FILE__) . 'widget/recent-post.php' );
	include_once( plugin_dir_path(__FILE__) . 'widget/section-one.php' );
	include_once( plugin_dir_path(__FILE__) . 'widget/section-two.php' );
	include_once( plugin_dir_path(__FILE__) . 'widget/section-three.php' );
	include_once( plugin_dir_path(__FILE__) . 'widget/section-four.php' );
	include_once( plugin_dir_path(__FILE__) . 'widget/section-five.php' );
	include_once( plugin_dir_path(__FILE__) . 'widget/section-ad.php' );
	include_once( plugin_dir_path(__FILE__) . 'widget/section-news.php' );
	include_once( plugin_dir_path(__FILE__) . 'widget/about-widget.php' );
	include_once( plugin_dir_path(__FILE__) . 'widget/social-widget.php' );
	include_once( plugin_dir_path(__FILE__) . 'inc/install.php' );
	include_once( plugin_dir_path(__FILE__) . 'customizer/customizer.php' );
	include_once( plugin_dir_path(__FILE__) . 'customizer/custom-customizer.php' );
	include_once( plugin_dir_path(__FILE__) . 'inc/custom-style.php' );
	include_once( plugin_dir_path(__FILE__) . 'inc/shortcode.php' );
?>