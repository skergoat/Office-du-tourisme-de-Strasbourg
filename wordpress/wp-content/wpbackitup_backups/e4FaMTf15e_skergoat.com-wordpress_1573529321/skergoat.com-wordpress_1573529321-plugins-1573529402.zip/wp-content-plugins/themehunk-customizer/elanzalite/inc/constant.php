<?php
  if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

define('THEMEHUNK_CUSTOMIZER_STYLE1', __(THEMEHUNK_CUSTOMIZER_PLUGIN_URL.'elanzalite/images/style1.png','themehunk-customizer'));
define('THEMEHUNK_CUSTOMIZER_STYLE2', __(THEMEHUNK_CUSTOMIZER_PLUGIN_URL.'elanzalite/images/style2.png','themehunk-customizer'));
define('THEMEHUNK_CUSTOMIZER_STYLE3', __(THEMEHUNK_CUSTOMIZER_PLUGIN_URL.'elanzalite/images/style3.png','themehunk-customizer'));
define('THEMEHUNK_CUSTOMIZER_STYLE4', __(THEMEHUNK_CUSTOMIZER_PLUGIN_URL.'elanzalite/images/style4.png','themehunk-customizer'));
define('THEMEHUNK_CUSTOMIZER_STYLE5', __(THEMEHUNK_CUSTOMIZER_PLUGIN_URL.'elanzalite/images/style5.png','themehunk-customizer'));
?>