( function($) {

	$( document ).ready(function () {

		$( '.themehunk-typography-select' ).onelineSelect();

	} );

} )( jQuery );