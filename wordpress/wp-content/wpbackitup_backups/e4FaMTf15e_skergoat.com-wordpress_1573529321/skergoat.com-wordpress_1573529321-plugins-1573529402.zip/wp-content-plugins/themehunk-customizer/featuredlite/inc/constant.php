<?php
define('FEATUREDLITE_THEME_URI',get_template_directory_uri());
define('FEATUREDLITE_HEADER_IMG', get_template_directory_uri().'/images/bg.jpg','featuredlite');
define('FEATUREDLITE_ABOUTUS', get_template_directory_uri().'/images/about-us.png','featuredlite');
