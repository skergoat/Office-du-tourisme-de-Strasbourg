<?php
		include_once( plugin_dir_path(__FILE__) . 'inc/constant.php' );
		include_once( plugin_dir_path(__FILE__) . 'widget/team.php' );
		include_once( plugin_dir_path(__FILE__) . 'widget/testimonial.php' );
		include_once( plugin_dir_path(__FILE__) . 'widget/services.php' );
		include_once( plugin_dir_path(__FILE__) . 'inc/install.php' );
		include_once( plugin_dir_path(__FILE__) . 'customizer/custom-customizer.php' );
		include_once( plugin_dir_path(__FILE__) . 'customizer/customizer.php' );
		include_once( plugin_dir_path(__FILE__) . 'inc/custom-style.php' );
		include_once( plugin_dir_path(__FILE__) . 'inc/shortcode.php' );
?>