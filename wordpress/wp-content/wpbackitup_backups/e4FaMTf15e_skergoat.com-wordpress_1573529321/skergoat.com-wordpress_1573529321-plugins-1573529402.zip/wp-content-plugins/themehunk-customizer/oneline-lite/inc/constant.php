<?php
  if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

define('THEMEHUNK_CUSTOMIZER_TEAM', __(THEMEHUNK_CUSTOMIZER_PLUGIN_URL.'oneline-lite/images/team.jpg','themehunk-customizer'));
define('THEMEHUNK_CUSTOMIZER_TESTIMONIAL', __(THEMEHUNK_CUSTOMIZER_PLUGIN_URL.'oneline-lite/images/testimonia.png','themehunk-customizer'));
define('THEMEHUNK_CUSTOMIZER_SLIDER', __(THEMEHUNK_CUSTOMIZER_PLUGIN_URL.'oneline-lite/images/slider.jpeg','themehunk-customizer'));
?>