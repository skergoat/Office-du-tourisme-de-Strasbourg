$(function(){

		// ombre nav responsive

$('#pull').click(function(){

	if(!$('.mobile-menu-wrapper').hasClass('ombre')) {

		$('.mobile-menu-wrapper').addClass('ombre');
	}
	else {

		function sansOmbres(){

			$('.mobile-menu-wrapper').removeClass('ombre');
		}

		setTimeout(sansOmbres, 450); 
	}

}); 

// disparition search zone au resize

$( window ).resize(function() {

	if($('#ma_nav').hasClass('disparait')){

		$('#ma_nav').removeClass('disparait');
		$('#ma_nav').animate({'top':'-=80px'}, {queue: false}).animate({'opacity':'1'}, {duration: 1100, queue: false});
		$('#ma_search_form').animate({'opacity':'0'}, {duration: 400, queue: false}).animate({'top':'-=35px'}, {queue: false}); 	
	}

	if($('#bouton_loupe_2').hasClass('disparait')){

		$('#bouton_loupe_2').removeClass('disparait');
		$('#bouton_loupe_2').animate({'top':'-=80px'}, {queue: false}).animate({'opacity':'1'}, {duration: 1100, queue: false});
		$('#ma_search_form_2').animate({'opacity':'0'}, {duration: 400, queue: false}).animate({'top':'-=35px'}, {queue: false});
	}

});

// zone de recherche navbar normale

	$('#ma_search_form').css('opacity', '0');

	$('#bouton_loupe').click(function(){

		$('#ma_nav').addClass('disparait');
		$('#ma_nav').animate({'opacity':'0'}, {duration: 200, queue: false}).animate({'top':'+=80px'}, {queue: false}); 
		$('#ma_search_form').animate({'opacity':'1'}, {duration: 400, queue: false}).animate({'top':'+=35px'}, {queue: false}); 

	});

	$('.bouton_retour').click(function(){

		$('#ma_nav').removeClass('disparait');
		$('#ma_nav').animate({'top':'-=80px'}, {queue: false}).animate({'opacity':'1'}, {duration: 1100, queue: false});
		$('#ma_search_form').animate({'opacity':'0'}, {duration: 400, queue: false}).animate({'top':'-=35px'}, {queue: false}); 	

	});

// zone de recherche navbar responsive


	$('#ma_search_form_2').css('opacity', '0');
	$('#bouton_loupe_2').css('position', 'relative');

	$('#bouton_loupe_2').click(function(){

		$('#bouton_loupe_2').addClass('disparait');
		$('#bouton_loupe_2').animate({'opacity':'0'}, {duration: 200, queue: false}).animate({'top':'+=80px'}, {queue: false}); 
		$('#ma_search_form_2').animate({'opacity':'1'}, {duration: 400, queue: false}).animate({'top':'+=35px'}, {queue: false}); 

	});

	$('.bouton_retour_2').click(function(){

		$('#bouton_loupe_2').removeClass('disparait');
		$('#bouton_loupe_2').animate({'top':'-=80px'}, {queue: false}).animate({'opacity':'1'}, {duration: 1100, queue: false});
		$('#ma_search_form_2').animate({'opacity':'0'}, {duration: 400, queue: false}).animate({'top':'-=35px'}, {queue: false}); 	

	});

// premier item du menu 

    //$('.active').addClass('test');
    //$('.test').removeClass('active');

// menu shrink

	if($(document).scrollTop() >= 100){

		$('#logo img').addClass('sans');
		$('.header.smaller').css('box-shadow', '0px 0px 8px 2px #000000');
	}

	$(document).on("scroll", function(){

		if($(document).scrollTop() >= 100){

			$('#logo img').removeClass('sans');
			$('#logo img').addClass('avec');  
			// classe active du menu
            //$('.test').removeClass('active');  
		}
		else {

			$('#logo img').removeClass('avec');
			$('#logo img').addClass('sans');
			// classe active du menu
			//$('.test').removeClass('active');
		}
    
	});

	// insertion div et logo bis au bas du slider 

	$("#slider-div").append('<div id="div_logo_bis" style="z-index:3;"><img src="https://skergoat.com/wordpress/wp-content/uploads/2019/09/Logo2.jpg" alt="logo bis" id="logo_bis" /></div>');


	// modifier titre page de blog

	$('.page-title .demo-image h2.title, .demo-image .archive-title h2').text('Actualités');

	// adaptation style pagination 

	$('.pagination').removeClass('navigation');

	});
