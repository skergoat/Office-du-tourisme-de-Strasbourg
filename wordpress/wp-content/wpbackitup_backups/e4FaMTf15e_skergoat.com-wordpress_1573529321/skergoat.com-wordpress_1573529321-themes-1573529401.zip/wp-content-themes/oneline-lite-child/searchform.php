<div class="srch clearfix">
    <form method="GET" action="<?php echo get_site_url(); ?>" class="ma-form">
    	<div class="container_input">
    		<label for ="q">
        	<input autocomplete="off" value="<?php the_search_query(); ?>" name="s" class="q">
        	<div class="help">cliquez sur "entrée" pour lancer la recherche</div>
        	</label>
        	<div class="bouton_retour"><i class="fas fa-times"></i></div>
        	<div class="bouton_retour_2"><i class="fas fa-times"></i></div>
        </div>
    </form>
</div>